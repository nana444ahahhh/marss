print("Content-type: text/html; charset=utf-8")
print()
print("<h1>Hello, Yandex!</h1>")